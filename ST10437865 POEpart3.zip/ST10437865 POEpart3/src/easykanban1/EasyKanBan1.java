package easykanban1;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class EasyKanBan1 {

    private static int taskCounter = 0; // Counter for generating task IDs

    // Arrays to store task data
    private static ArrayList<String> developers = new ArrayList<>();
    private static ArrayList<String> taskNames = new ArrayList<>();
    private static ArrayList<String> taskIDs = new ArrayList<>();
    private static ArrayList<Integer> taskDurations = new ArrayList<>();
    private static ArrayList<String> taskStatuses = new ArrayList<>();

    public static void main(String[] args) {
        String name = JOptionPane.showInputDialog(null, "Enter Your Name");
        String surname = JOptionPane.showInputDialog(null, "Enter Your Surname");

        String username = JOptionPane.showInputDialog(null, "Enter Your Username");
        String password = JOptionPane.showInputDialog(null, "Enter Your Password");

        // Example of authentication logic
        if (username.equals("MM_pe") && password.equals("Shor2tb@")) {
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

            // Main menu loop
            int option;
            do {
                // Display menu options
                String input = JOptionPane.showInputDialog(
                        "Choose an option:\n" +
                                "1) Add Task\n" +
                                "2) Show Report\n" +
                                "3) Search Task\n" +
                                "4) Delete Task\n" +
                                "5) Exit");
                // Parse the option and handle exceptions
                option = parseIntSafely(input, "Choose an option:");
                switch (option) {
                    case 1:
                        addTask();
                        break;
                    case 2:
                        showReport();
                        break;
                    case 3:
                        searchTask();
                        break;
                    case 4:
                        deleteTask();
                        break;
                    case 5:
                        JOptionPane.showMessageDialog(null, "Exiting application, Goodbye!");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid option. Please try again");
                }
            } while (option != 5);

        } else {
            JOptionPane.showMessageDialog(null, "Invalid login credentials");
        }
    }

    public static void addTask() {
        // Prompt user to enter task details
        int taskNumber = parseIntSafely(JOptionPane.showInputDialog("Enter task number:"), "Enter task number:");
        String taskName = JOptionPane.showInputDialog("Enter task name:");

        String taskDescription;
        while (true) {
            taskDescription = JOptionPane.showInputDialog("Enter task description (max 50 characters):");
            if (taskDescription.length() <= 50) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
            }
        }

        String developerDetails = JOptionPane.showInputDialog("Enter developer details (First and Last name):");
        int taskDuration = parseIntSafely(JOptionPane.showInputDialog("Enter task duration (in hours):"), "Enter task duration (in hours):");
        String taskStatus = (String) JOptionPane.showInputDialog(null, "Select task status:",
                "Task Status", JOptionPane.QUESTION_MESSAGE, null,
                new String[]{"To Do", "Done", "Doing"}, "To Do");

        Task task = createTask(taskNumber, taskName, taskDescription, developerDetails, taskDuration, taskStatus);
        if (task != null) {
            displayTask(task);
            // Store task details in arrays
            developers.add(developerDetails);
            taskNames.add(taskName);
            taskIDs.add("TASK" + taskCounter);
            taskDurations.add(taskDuration);
            taskStatuses.add(taskStatus);
            taskCounter++;
        }
    }

    private static Task createTask(int taskNumber, String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        return new Task(taskNumber, taskName, taskDescription, developerDetails, taskDuration, taskStatus);
    }

    private static void displayTask(Task task) {
        JOptionPane.showMessageDialog(null, task.toString());
    }

    private static int parseIntSafely(String input, String prompt) {
        while (true) {
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                input = JOptionPane.showInputDialog(null, "Invalid input. Please enter a valid number", prompt, JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void showReport() {
        StringBuilder report = new StringBuilder("Task Report:\n");

        // a. Display the Developer, Task Names and Task Duration for all tasks with the status of done.
        report.append("\nTasks with status 'Done':\n");
        for (int i = 0; i < taskStatuses.size(); i++) {
            if ("Done".equalsIgnoreCase(taskStatuses.get(i))) {
                report.append("Developer: ").append(developers.get(i)).append(", ");
                report.append("Task Name: ").append(taskNames.get(i)).append(", ");
                report.append("Task Duration: ").append(taskDurations.get(i)).append(" hours\n");
            }
        }

        // b. Display the Developer and Duration of the task with the longest duration.
        int maxDurationIndex = 0;
        for (int i = 1; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > taskDurations.get(maxDurationIndex)) {
                maxDurationIndex = i;
            }
        }
        report.append("\nTask with the longest duration:\n");
        report.append("Developer: ").append(developers.get(maxDurationIndex)).append(", ");
        report.append("Duration: ").append(taskDurations.get(maxDurationIndex)).append(" hours\n");

        // Display the report
        JOptionPane.showMessageDialog(null, report.toString());
    }

    private static void searchTask() {
        String searchOption = (String) JOptionPane.showInputDialog(null, "Search Options:",
                "Search Task", JOptionPane.QUESTION_MESSAGE, null,
                new String[]{"Task Name", "Developer"}, "Task Name");

        if ("Task Name".equals(searchOption)) {
            String taskName = JOptionPane.showInputDialog("Enter the Task Name:");
            for (int i = 0; i < taskNames.size(); i++) {
                if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                    JOptionPane.showMessageDialog(null, "Task Name: " + taskNames.get(i) +
                            "\nDeveloper: " + developers.get(i) +
                            "\nTask Status: " + taskStatuses.get(i));
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "Task not found.");
        } else if ("Developer".equals(searchOption)) {
            String developer = JOptionPane.showInputDialog("Enter the Developer Name:");
            StringBuilder tasksByDeveloper = new StringBuilder("Tasks assigned to " + developer + ":\n");
            boolean found = false;
            for (int i = 0; i < developers.size(); i++) {
                if (developers.get(i).equalsIgnoreCase(developer)) {
                    tasksByDeveloper.append("Task Name: ").append(taskNames.get(i))
                            .append(", Task Status: ").append(taskStatuses.get(i)).append("\n");
                    found = true;
                }
            }
            if (found) {
                JOptionPane.showMessageDialog(null, tasksByDeveloper.toString());
            } else {
                JOptionPane.showMessageDialog(null, "No tasks found for the developer.");
            }
        }
    }

    private static void deleteTask() {
        String taskName = JOptionPane.showInputDialog("Enter the Task Name to delete:");
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                developers.remove(i);
                taskNames.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                JOptionPane.showMessageDialog(null, "Task '" + taskName + "' has been deleted.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found.");
    }
}
